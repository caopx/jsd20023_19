package test06;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;

import test03.putInname;

public class Test {

	public static void main(String[] args) {
		Person p1=new Person();
		System.out.println(p1.toString());
	}
	public static void writeobj() throws FileNotFoundException, IOException {
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream("a.txt"));
		oos.writeObject(new Person("tom",22,"��","��һ��˧�����ˣ�"));
		oos.close();
	}
	public static void readobj() throws FileNotFoundException, IOException {
		ObjectOutputStream ois=new ObjectOutputStream(new FileOutputStream("a.txt"));
		Person p=(Person)ois.readObject();
		ois.close();
		System.out.println(p);
		ois.close();
	}
}
