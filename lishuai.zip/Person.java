package test06;

public class Person {
private int age;
private String name;
private String gender;
private String decs;

	public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getDecs() {
	return decs;
}
public void setDecs(String decs) {
	this.decs = decs;
}
	
		public String toString(){
	        return  name+","+age+","+gender+","+decs;
	    }
}