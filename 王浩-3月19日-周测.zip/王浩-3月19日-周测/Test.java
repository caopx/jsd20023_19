package test4;

import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.println("��������Ϣ��");
	    String str = sc.next();
	}
	

}
